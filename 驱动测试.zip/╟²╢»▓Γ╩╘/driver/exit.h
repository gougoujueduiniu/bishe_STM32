#ifndef __EXIT_H__
#define __EXIT_H__


#include "stm32f10x.h"

void Exit_Init(void);



#endif

