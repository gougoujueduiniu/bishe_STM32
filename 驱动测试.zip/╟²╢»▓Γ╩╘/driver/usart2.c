#include "stm32f10x.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_exti.h"
#include "misc.h"
#include "usart2.h"
#include "stm32f10x.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "utils.h"
#include "delay.h"

volatile unsigned char  gprs_ready_flag = 0;
volatile unsigned char  gprs_ready_count = 0;

unsigned char  usart2_rcv_buf[MAX_RCV_LEN];
volatile unsigned int   usart2_rcv_len = 0;

/*
 *  @brief USART2初始化函数
 */
void USART2_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    /* config USART2 clock */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA , ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

    /* USART2 GPIO config */
	/* Set PA2 PA3 as UART1 */
    /* Configure USART2 Tx (PA.02) as alternate function push-pull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    /* Configure USART2 Rx (PA.03) as input floating */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /* USART2 mode config */
    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No ;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART2, &USART_InitStructure);
    USART_Cmd(USART2, ENABLE);

    //Enable usart2 receive interrupt
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

/*
*  @brief USART2串口接收状态初始化
*/
void USART2_Clear(void)
{
	memset(usart2_rcv_buf, 0, strlen(usart2_rcv_buf));
    usart2_rcv_len = 0;
}

/*
*  @brief USART2串口发送api
*/
void USART2_Write(USART_TypeDef* USARTx, uint8_t *Data, uint8_t len)
{
    uint8_t i;
    USART_ClearFlag(USARTx, USART_FLAG_TC);
    for(i = 0; i < len; i++)
    {
        USART_SendData(USARTx, *Data++);
        while( USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET );
    }
}

/*
 *  @brief USART2串口发送AT命令用
 *  @para  cmd  AT命令
 *  @para  result 预期的正确返回信息
 *  @para  timeOut延时时间,ms
 */
void SendCmd(char* cmd, char* result, int timeOut)
{
    while(1)
    {
        USART2_Clear();
        USART2_Write(USART2, cmd, strlen(cmd));
        mDelay(timeOut);
//        printf("%s %d cmd:%s,rsp:%s\n", __func__, __LINE__, cmd, usart2_rcv_buf);
        if((NULL != strstr(usart2_rcv_buf, result)))	//判断是否有预期的结果
        {
            break;
        }
        else
        {
            mDelay(100);
        }
    }
}

#if 1
/*
 *  @brief 返回USART2新接收的数据长度
 */
uint32_t USART2_GetRcvNum(void)
{
	static uint32_t len = 0;
	uint32_t result = 0;
	
	if(usart2_rcv_len == 0)
	{
		len = 0;
		result = 0;
	}
	else if(len != usart2_rcv_len)
	{
		result = usart2_rcv_len - len;	//新接收长度
		len = usart2_rcv_len;			//保存新长度
	}
	
    return result;
}

/*
 *  @brief 返回USART2已接收的数据到buf，长度为rcv_len
 */
void  USART2_GetRcvData(uint8_t *buf, uint32_t rcv_len)
{
    if(buf)
    {
        memcpy(buf, usart2_rcv_buf, rcv_len);
    }
    //USART2_Clear();
}
#endif


void USART2_IRQHandler(void)
{
    unsigned int data;
#if 1
    if(USART2->SR & 0x0F)
    {
        // See if we have some kind of error
        // Clear interrupt (do nothing about it!)
        data = USART2->DR;
    }
    else if(USART2->SR & USART_FLAG_RXNE)   //Receive Data Reg Full Flag
    {
        //GPIO_SetBits(GPIOC,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3);
        data = USART2->DR;
        usart2_rcv_buf[usart2_rcv_len++] = data;
		if(usart2_rcv_len >= MAX_RCV_LEN - 1)
			usart2_rcv_len = 0;
        //usart1_rcv_buf[usart1_rcv_len++]=data;
        //usart1_putrxchar(data);       //Insert received character into buffer
    }
    else
    {
        ;
    }
#endif
}




void Esp8266_Init()
{
	SendCmd("AT\r\n","OK",3000);
	GPIOC->ODR ^= (uint16_t)1<<13;
	delay_ms(1000);
	GPIOC->ODR ^= (uint16_t)1<<13;
	SendCmd("AT+CWMODE=1\r\n","OK",3000);
	SendCmd("AT+CWJAP_DEF=\"5113\",\"zxc511511\"\r\n","OK",3000);
	SendCmd("AT+CIPMUX=0\r\n","OK",3000);
	SendCmd("AT+CIPSTART=\"TCP\",\"192.168.0.117\",50000\r\n","OK",3000);
	GPIOC->ODR ^= (uint16_t)1<<13;
	delay_ms(500);
	GPIOC->ODR ^= (uint16_t)1<<13;
	delay_ms(500);
	GPIOC->ODR ^= (uint16_t)1<<13;
}

