#ifndef __HEAD_H__
#define __HEAD_H__

#include "string.h"

#define ZHONGJIAN    0x02
#define ZUOYI        0x01 
#define ZUOER        0x03    
#define YOUYI        0x04 
#define YOUER        0x06
 
#define ZHIXING      1
#define YOUZHUAN     2
#define ZUOZHUAN     3

#define EAST				 1
#define SOUTH    		 2
#define	WEST				 3
#define	NORTH   		 4

#define	DAMEN        0
#define GANMAO       1
#define CHUANGSHANG  2
#define ZHOANGYAO    3
#define XIAOHUA      4


#endif
