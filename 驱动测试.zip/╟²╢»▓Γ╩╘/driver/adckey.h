#ifndef __ADCKEY_H__
#define __ADCKEY_H__


#include "stm32f10x.h"

void AdcKey_Init(void);
uint16_t GET_ADConverter(void);


#endif

